//1.ageappropriate project


 let age = prompt('boyos koto?');



if( age >= 18  ){
    console.log(`ji apner biye er boyos hoisa `);

}else{
    console.log(`na tmi akhno bacca aso, doya kore ${ 18 - age } opekkha koro`);

}