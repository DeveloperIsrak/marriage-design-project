let age = prompt('put your age here..');


if( age >= 20 && age <=35 ){
    console.log('ji vai apnar jonnoi atto kisu ranna korci , plz khaye jan')
}else if( age >= 35 ){
    console.log('vai apne bura manus kaite parben na')
}